jQuery(document).ready(function(){
	$('.directions-blocks').slick({
		dots: true,
		arrows: false,
		slidesToShow: 3,
		slidesToScroll: 3
	});
	var menuBtn = $('.top-nav_btn');
	var menu = $('.top-nav_menu');

	menuBtn.on('click', function(event) {
		event.preventDefault();
		menu.slideToggle(300);
	});
	
});
